package ui;

import javax.swing.SwingUtilities;

public class RodarTSP {

	
	public static void main(String[] args) {


		
		
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				JFrameTSP frame = new JFrameTSP(null);
								
			}
		});
		
		

	}

}
