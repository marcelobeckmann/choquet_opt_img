echo ---------------------- 1
java -cp .:tsp.jar choquet.Start
echo ---------------------- 2
java -cp .:tsp.jar choquet.Start
echo ---------------------- 3
java -cp .:tsp.jar choquet.Start
echo ---------------------- 4
java -cp .:tsp.jar choquet.Start
echo ---------------------- 5
java -cp .:tsp.jar choquet.Start
echo ---------------------- 6
java -cp .:tsp.jar choquet.Start
echo ---------------------- 7
java -cp .:tsp.jar choquet.Start
echo ---------------------- 8
java -cp .:tsp.jar choquet.Start
echo ---------------------- 9
java -cp .:tsp.jar choquet.Start
echo ---------------------- 10
java -cp .:tsp.jar choquet.Start

