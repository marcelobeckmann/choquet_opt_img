package choquet;

import javax.swing.SwingUtilities;

import ui.JFrameTSP;


public class Start {

	public static void main(String[] args) {

		int region=1;
		Engine.setRegion(region);
		final Engine ecosystem = new Engine();
		int i=0;
		//for (int i = 1; i <= 30; i++) {

			System.out.println("#### " + i + " ---------------- R"+ Engine.getRegion());
			 
			
			Parameter[] genes = new Parameter[Engine.PARAMETERS];
			
			genes[0]= new Parameter(0.7203);
			genes[1]= new Parameter(0.83601);
			genes[2]= new Parameter(0.94311066);
			genes[3]= new Parameter(0.015834);
			genes[4]= new Parameter(0.769082);
			genes[5]= new Parameter(0.8916049);
			ecosystem.setExpertParameters(genes);
			ecosystem.setDiscardPenalty(true);
			ecosystem.setPopulacaoInicial(350);
			ecosystem.setPopulacaoMaxima(100);
			ecosystem.setPercentualMutacao(5);
			ecosystem.setPercentualCruzamento(60);
			ecosystem.setMaximoGeracoes(100);
			ecosystem.setDebug(true);
			ecosystem.setPrecision(6);
			ecosystem.setExpertNeighborhood(0.1);
			ecosystem.setNeighborhoodRelaxationLimit(0.03);
			//Thread t = new Thread(ecosystem);

			//t.run();
			

			SwingUtilities.invokeLater(new Runnable() {
				public void run() {
					JFrameTSP frame = new JFrameTSP(ecosystem);
									
				}
			});
			

		//}

	}



}
